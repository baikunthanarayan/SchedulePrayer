import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("bookings.db");

// Initialize database
db.exec(`
  CREATE TABLE IF NOT EXISTS bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT,
    date TEXT NOT NULL,
    location TEXT,
    slot TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS prayer_times (
    month TEXT PRIMARY KEY,
    morning TEXT NOT NULL,
    evening TEXT NOT NULL
  );
`);

// Seed initial prayer times if empty
const count = db.prepare("SELECT COUNT(*) as count FROM prayer_times").get() as { count: number };
if (count.count === 0) {
  const initialTimes = [
    { month: "January", morning: "06:44 AM", evening: "06:10 PM" },
    { month: "February", morning: "06:40 AM", evening: "06:23 PM" },
    { month: "March", morning: "06:24 AM", evening: "06:28 PM" },
    { month: "April", morning: "06:04 AM", evening: "06:31 PM" },
    { month: "May", morning: "05:52 AM", evening: "06:37 PM" },
    { month: "June", morning: "05:51 AM", evening: "06:46 PM" },
    { month: "July", morning: "05:59 AM", evening: "06:48 PM" },
    { month: "August", morning: "06:05 AM", evening: "06:38 PM" },
    { month: "September", morning: "06:06 AM", evening: "06:19 PM" },
    { month: "October", morning: "06:09 AM", evening: "05:58 PM" },
    { month: "November", morning: "06:18 AM", evening: "05:48 PM" },
    { month: "December", morning: "06:34 AM", evening: "05:54 PM" },
  ];
  const insert = db.prepare("INSERT INTO prayer_times (month, morning, evening) VALUES (?, ?, ?)");
  initialTimes.forEach(t => insert.run(t.month, t.morning, t.evening));
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/bookings", (req, res) => {
    const bookings = db.prepare("SELECT * FROM bookings ORDER BY created_at DESC").all();
    res.json(bookings);
  });

  app.post("/api/bookings", (req, res) => {
    const { name, phone, date, location, slot } = req.body;
    if (!name || !date || !slot) {
      return res.status(400).json({ error: "Missing required fields" });
    }
    const info = db.prepare("INSERT INTO bookings (name, phone, date, location, slot) VALUES (?, ?, ?, ?, ?)").run(name, phone, date, location, slot);
    res.json({ id: info.lastInsertRowid, name, phone, date, location, slot });
  });

  app.put("/api/bookings/:id", (req, res) => {
    const { id } = req.params;
    const { name, phone, date, location, slot } = req.body;
    db.prepare("UPDATE bookings SET name = ?, phone = ?, date = ?, location = ?, slot = ? WHERE id = ?").run(name, phone, date, location, slot, id);
    res.json({ success: true });
  });

  app.delete("/api/bookings/:id", (req, res) => {
    const { id } = req.params;
    db.prepare("DELETE FROM bookings WHERE id = ?").run(id);
    res.json({ success: true });
  });

  app.get("/api/stats", (req, res) => {
    const total = db.prepare("SELECT COUNT(*) as count FROM bookings").get() as { count: number };
    res.json({ total: total.count });
  });

  // Prayer Times API
  app.get("/api/prayer-times", (req, res) => {
    const times = db.prepare("SELECT * FROM prayer_times").all();
    res.json(times);
  });

  app.post("/api/prayer-times", (req, res) => {
    const times = req.body; // Array of { month, morning, evening }
    if (!Array.isArray(times)) return res.status(400).json({ error: "Invalid data format" });

    const deleteStmt = db.prepare("DELETE FROM prayer_times");
    const insertStmt = db.prepare("INSERT INTO prayer_times (month, morning, evening) VALUES (?, ?, ?)");

    const transaction = db.transaction((data) => {
      deleteStmt.run();
      for (const item of data) {
        insertStmt.run(item.month, item.morning, item.evening);
      }
    });

    transaction(times);
    res.json({ success: true });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
