/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Calendar, 
  Clock, 
  User, 
  Plus, 
  Edit2, 
  Trash2, 
  CheckCircle, 
  AlertCircle,
  ChevronRight,
  Sun,
  Moon,
  Info,
  Phone,
  MapPin,
  Settings,
  Upload,
  Save,
  FileText,
  ChevronLeft,
  MoreVertical
} from 'lucide-react';

interface PrayerTime {
  month: string;
  morning: string;
  evening: string;
}

interface Booking {
  id: number;
  name: string;
  phone: string;
  date: string;
  location: string;
  slot: string;
  created_at: string;
}

const NamasteIcon = () => (
  <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor" className="inline-block mr-2">
    <path d="M12,2A1,1 0 0,1 13,3V5.18C15.83,5.63 18,8.06 18,11V16L21,19V20H3V19L6,16V11C6,8.06 8.17,5.63 11,5.18V3A1,1 0 0,1 12,2M12,22A2,2 0 0,1 10,20H14A2,2 0 0,1 12,22Z" />
    {/* Simple bell icon as a placeholder for namaste if not available, or just use a custom path */}
    <path d="M12,2C10.89,2 10,2.89 10,4C10,5.11 10.89,6 12,6C13.11,6 14,5.11 14,4C14,2.89 13.11,2 12,2M12,8C9.79,8 8,9.79 8,12V17H16V12C16,9.79 14.21,8 12,8M10,19V21H14V19H10Z" />
  </svg>
);

// Better Namaste SVG
const NamasteSVG = () => (
  <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600">
    <path d="M12 20c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2s2 .9 2 2v12c0 1.1-.9 2-2 2Z" />
    <path d="M10 18c-2.2 0-4-1.8-4-4V8c0-2.2 1.8-4 4-4" />
    <path d="M14 18c2.2 0 4-1.8 4-4V8c0-2.2-1.8-4-4-4" />
    <path d="M10 10l-2 2 2 2" />
    <path d="M14 10l2 2-2 2" />
  </svg>
);

export default function App() {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [prayerTimes, setPrayerTimes] = useState<PrayerTime[]>([]);
  const [totalBookings, setTotalBookings] = useState(0);
  const [activeTab, setActiveTab] = useState<'book' | 'manage' | 'admin'>('book');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [date, setDate] = useState('');
  const [location, setLocation] = useState('');
  const [slot, setSlot] = useState('Morning Prayer');
  const [editingId, setEditingId] = useState<number | null>(null);

  // Admin states
  const [adminTimes, setAdminTimes] = useState<PrayerTime[]>([]);
  const [currentCalendarDate, setCurrentCalendarDate] = useState(new Date());
  const fileInputRef = useRef<HTMLInputElement>(null);

  const currentMonthIndex = new Date().getMonth();
  const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  const currentMonthName = months[currentMonthIndex];
  
  const currentPrayerTime = prayerTimes.find(t => t.month === currentMonthName) || { month: currentMonthName, morning: "--:--", evening: "--:--" };

  useEffect(() => {
    fetchBookings();
    fetchStats();
    fetchPrayerTimes();
  }, []);

  const fetchBookings = async () => {
    try {
      const res = await fetch('/api/bookings');
      const data = await res.json();
      setBookings(data);
    } catch (err) {
      console.error("Failed to fetch bookings", err);
    }
  };

  const fetchStats = async () => {
    try {
      const res = await fetch('/api/stats');
      const data = await res.json();
      setTotalBookings(data.total);
    } catch (err) {
      console.error("Failed to fetch stats", err);
    }
  };

  const fetchPrayerTimes = async () => {
    try {
      const res = await fetch('/api/prayer-times');
      const data = await res.json();
      setPrayerTimes(data);
      setAdminTimes(data);
    } catch (err) {
      console.error("Failed to fetch prayer times", err);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage(null);

    const url = editingId ? `/api/bookings/${editingId}` : '/api/bookings';
    const method = editingId ? 'PUT' : 'POST';

    try {
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, phone, date, location, slot }),
      });

      if (res.ok) {
        setMessage({ type: 'success', text: editingId ? 'Slot updated successfully!' : 'Slot booked successfully!' });
        setName('');
        setPhone('');
        setDate('');
        setLocation('');
        setSlot('Morning Prayer');
        setEditingId(null);
        fetchBookings();
        fetchStats();
        if (editingId) setActiveTab('manage');
      } else {
        setMessage({ type: 'error', text: 'Failed to save booking. Please try again.' });
      }
    } catch (err) {
      setMessage({ type: 'error', text: 'An error occurred. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (booking: Booking) => {
    setEditingId(booking.id);
    setName(booking.name);
    setPhone(booking.phone || '');
    setDate(booking.date);
    setLocation(booking.location || '');
    setSlot(booking.slot);
    setActiveTab('book');
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Are you sure you want to cancel this slot?')) return;

    try {
      const res = await fetch(`/api/bookings/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setMessage({ type: 'success', text: 'Slot cancelled successfully!' });
        fetchBookings();
        fetchStats();
      }
    } catch (err) {
      setMessage({ type: 'error', text: 'Failed to cancel slot.' });
    }
  };

  const handleAdminTimeChange = (index: number, field: keyof PrayerTime, value: string) => {
    const newTimes = [...adminTimes];
    newTimes[index] = { ...newTimes[index], [field]: value };
    setAdminTimes(newTimes);
  };

  const saveAdminTimes = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/prayer-times', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(adminTimes),
      });
      if (res.ok) {
        setMessage({ type: 'success', text: 'Prayer times updated successfully!' });
        fetchPrayerTimes();
      } else {
        setMessage({ type: 'error', text: 'Failed to update prayer times.' });
      }
    } catch (err) {
      setMessage({ type: 'error', text: 'Error updating prayer times.' });
    } finally {
      setLoading(false);
    }
  };

  const handleCsvUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      const lines = text.split('\n');
      const newTimes: PrayerTime[] = [];
      
      // Expected format: Month,Morning,Evening
      for (let i = 1; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;
        const [month, morning, evening] = line.split(',');
        if (month && morning && evening) {
          newTimes.push({ month: month.trim(), morning: morning.trim(), evening: evening.trim() });
        }
      }

      if (newTimes.length > 0) {
        setAdminTimes(newTimes);
        setMessage({ type: 'success', text: `Parsed ${newTimes.length} months from CSV. Click Save to apply.` });
      } else {
        setMessage({ type: 'error', text: 'Invalid CSV format. Expected: Month,Morning,Evening' });
      }
    };
    reader.readAsText(file);
  };

  const renderCalendar = () => {
    const year = currentCalendarDate.getFullYear();
    const month = currentCalendarDate.getMonth();
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const days = [];

    // Empty slots for previous month
    for (let i = 0; i < firstDay; i++) {
      days.push(<div key={`empty-${i}`} className="h-12" />);
    }

    for (let d = 1; d <= daysInMonth; d++) {
      const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
      const isBooked = bookings.some(b => b.date === dateStr);
      const isSelected = date === dateStr;
      const isToday = new Date().toISOString().split('T')[0] === dateStr;

      days.push(
        <button
          key={d}
          type="button"
          onClick={() => setDate(dateStr)}
          className={`h-12 w-full relative flex flex-col items-center justify-center rounded-xl transition-all ${
            isSelected 
              ? 'bg-blue-600 text-white shadow-lg z-10' 
              : isBooked 
                ? 'bg-rose-50 text-rose-600' 
                : 'hover:bg-blue-50 text-slate-400'
          }`}
        >
          <span className={`text-sm font-bold ${isSelected ? 'text-white' : isBooked ? 'text-rose-500' : 'text-slate-600'}`}>
            {d}
          </span>
          {isBooked && !isSelected && (
            <span className="absolute -bottom-1 text-[8px] font-black uppercase text-rose-500 tracking-tighter">
              BOOKED
            </span>
          )}
          {isSelected && (
            <div className="absolute -top-1 right-1 w-1.5 h-1.5 bg-white rounded-full border border-blue-600" />
          )}
        </button>
      );
    }

    return days;
  };

  const changeMonth = (offset: number) => {
    const newDate = new Date(currentCalendarDate);
    newDate.setMonth(newDate.getMonth() + offset);
    setCurrentCalendarDate(newDate);
  };

  const formatDateDisplay = (dateStr: string) => {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    const day = d.getDate();
    const month = d.toLocaleString('default', { month: 'short' }).toUpperCase();
    const year = d.getFullYear();
    
    const suffix = (day: number) => {
      if (day > 3 && day < 21) return 'TH';
      switch (day % 10) {
        case 1: return "ST";
        case 2: return "ND";
        case 3: return "RD";
        default: return "TH";
      }
    };

    return `${month} ${day}${suffix(day)}, ${year}`;
  };

  return (
    <div className="min-h-screen bg-[#e8f0fe] relative overflow-hidden font-sans text-slate-900">
      {/* Divine Background Elements */}
      <div className="fixed inset-0 z-0 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-b from-[#b8ccff] via-[#dce9ff] to-[#f5f8ff]" />
        <div className="absolute top-0 left-0 w-full h-[55vh] bg-[radial-gradient(ellipse_at_50%_-5%,rgba(99,145,255,0.45)_0%,transparent_50%)]" />
        
        {/* Animated Rays */}
        <div className="absolute top-0 left-0 w-full h-full opacity-20">
          {[...Array(8)].map((_, i) => (
            <div 
              key={i}
              className="absolute top-0 w-[2px] h-[60vh] bg-gradient-to-b from-blue-400 to-transparent origin-top animate-pulse"
              style={{ 
                left: `${10 + i * 12}%`, 
                transform: `rotate(${(i - 4) * 5}deg)`,
                animationDelay: `${i * 0.5}s`
              }}
            />
          ))}
        </div>
      </div>

      <div className="relative z-10 max-w-4xl mx-auto px-4 py-8">
        {/* Header Section */}
        <header className="text-center mb-8">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center mb-4"
          >
            <div className="flex items-center gap-2 text-blue-800 font-bold text-2xl mb-2">
              <NamasteSVG />
              <span className="font-display tracking-widest">JAYAGURU</span>
            </div>
            <div className="w-16 h-1 bg-blue-200 rounded-full mb-6" />
          </motion.div>
          
          <motion.h1 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-4xl md:text-5xl font-bold text-blue-900 mb-2 tracking-tight"
          >
            Book Prayer Slot
          </motion.h1>
          <p className="text-blue-600 font-medium uppercase tracking-widest text-sm">Budigere Cross</p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Column: Prayer Times & Stats */}
          <div className="lg:col-span-4 space-y-6">
            {/* Prayer Times Card */}
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-white/80 backdrop-blur-md rounded-3xl p-6 border border-blue-100 shadow-xl"
            >
              <div className="flex items-center gap-2 mb-4 text-blue-900 font-bold">
                <Clock className="w-5 h-5" />
                <h2>Bangalore Prayer Times</h2>
              </div>
              <div className="space-y-4">
                <div className="p-3 bg-blue-50 rounded-2xl border border-blue-100 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-blue-100 rounded-lg">
                      <Sun className="w-4 h-4 text-blue-600" />
                    </div>
                    <span className="text-sm font-semibold text-blue-800">Morning</span>
                  </div>
                  <span className="text-lg font-bold text-blue-900">{currentPrayerTime.morning}</span>
                </div>
                <div className="p-3 bg-indigo-50 rounded-2xl border border-indigo-100 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-indigo-100 rounded-lg">
                      <Moon className="w-4 h-4 text-indigo-600" />
                    </div>
                    <span className="text-sm font-semibold text-indigo-800">Evening</span>
                  </div>
                  <span className="text-lg font-bold text-indigo-900">{currentPrayerTime.evening}</span>
                </div>
              </div>
              <div className="mt-4 pt-2 text-center">
                <span className="text-lg font-bold text-blue-700 tracking-wide">
                  {currentMonthName}
                </span>
              </div>
            </motion.div>

            {/* Stats Card */}
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-gradient-to-br from-blue-600 to-indigo-700 rounded-3xl p-6 text-white shadow-xl shadow-blue-200"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-blue-100 text-sm font-medium">Total Bookings</span>
                <CheckCircle className="w-5 h-5 text-blue-200" />
              </div>
              <div className="text-4xl font-black">{totalBookings}</div>
              <p className="text-blue-100 text-xs mt-2 opacity-80">Slots reserved across all sessions</p>
            </motion.div>

            {/* Admin Access Button */}
            <button
              onClick={() => setActiveTab('admin')}
              className="w-full py-3 bg-white/50 hover:bg-white/80 border border-blue-100 rounded-2xl text-blue-600 text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2 transition-all"
            >
              <Settings className="w-4 h-4" /> Admin Panel
            </button>
          </div>

          {/* Right Column: Main Content */}
          <div className="lg:col-span-8 space-y-6">
            {/* Tabs */}
            <div className="flex p-1 bg-white/50 backdrop-blur-sm rounded-2xl border border-blue-100 shadow-sm">
              <button
                onClick={() => { setActiveTab('book'); setEditingId(null); setName(''); setPhone(''); setDate(''); setLocation(''); setSlot('Morning Prayer'); }}
                className={`flex-1 py-3 rounded-xl text-sm font-bold transition-all ${activeTab === 'book' ? 'bg-blue-600 text-white shadow-lg' : 'text-blue-600 hover:bg-blue-50'}`}
              >
                {editingId ? 'Edit Slot' : 'Book Prayer Slot'}
              </button>
              <button
                onClick={() => setActiveTab('manage')}
                className={`flex-1 py-3 rounded-xl text-sm font-bold transition-all ${activeTab === 'manage' ? 'bg-blue-600 text-white shadow-lg' : 'text-blue-600 hover:bg-blue-50'}`}
              >
                Manage Bookings
              </button>
            </div>

            <AnimatePresence mode="wait">
              {activeTab === 'book' ? (
                <motion.div
                  key="book-tab"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="space-y-6"
                >
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Custom Calendar */}
                    <div className="bg-white rounded-3xl p-6 shadow-xl border border-blue-50">
                      <div className="flex items-center justify-between mb-6 px-2">
                        <h3 className="text-xl font-bold text-blue-900">
                          {currentCalendarDate.toLocaleString('default', { month: 'long', year: 'numeric' })}
                        </h3>
                        <div className="flex gap-2">
                          <button onClick={() => changeMonth(-1)} className="p-2 hover:bg-blue-50 rounded-full text-blue-600 transition-colors">
                            <ChevronLeft className="w-5 h-5" />
                          </button>
                          <button onClick={() => changeMonth(1)} className="p-2 hover:bg-blue-50 rounded-full text-blue-600 transition-colors">
                            <ChevronRight className="w-5 h-5" />
                          </button>
                        </div>
                      </div>

                      <div className="grid grid-cols-7 gap-1 mb-2">
                        {['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'].map(day => (
                          <div key={day} className="text-center text-[10px] font-black text-blue-400 py-2">
                            {day}
                          </div>
                        ))}
                      </div>

                      <div className="grid grid-cols-7 gap-1">
                        {renderCalendar()}
                      </div>

                      <div className="mt-8 flex items-center justify-between px-2">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 bg-blue-600 rounded-full" />
                          <span className="text-[10px] font-bold text-blue-600 uppercase">Selected</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 bg-rose-100 rounded-full" />
                          <span className="text-[10px] font-bold text-blue-600 uppercase">Booked</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 border border-blue-200 rounded-full" />
                          <span className="text-[10px] font-bold text-blue-600 uppercase">Available</span>
                        </div>
                      </div>
                    </div>

                    {/* Form Fields */}
                    <div className="bg-white rounded-3xl p-6 shadow-xl border border-blue-50 space-y-6">
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-blue-400 uppercase tracking-widest flex items-center gap-2">
                          <User className="w-3 h-3" /> Full Name
                        </label>
                        <input
                          type="text"
                          required
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          placeholder="Enter your name"
                          className="w-full px-4 py-3 rounded-xl bg-blue-50/50 border border-blue-100 focus:border-blue-500 outline-none transition-all text-blue-900 font-medium text-sm"
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="text-xs font-bold text-blue-400 uppercase tracking-widest flex items-center gap-2">
                          <Phone className="w-3 h-3" /> Phone Number
                        </label>
                        <input
                          type="tel"
                          required
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          placeholder="Enter phone number"
                          className="w-full px-4 py-3 rounded-xl bg-blue-50/50 border border-blue-100 focus:border-blue-500 outline-none transition-all text-blue-900 font-medium text-sm"
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="text-xs font-bold text-blue-400 uppercase tracking-widest flex items-center gap-2">
                          <MapPin className="w-3 h-3" /> Location
                        </label>
                        <input
                          type="text"
                          value={location}
                          onChange={(e) => setLocation(e.target.value)}
                          placeholder="Enter location"
                          className="w-full px-4 py-3 rounded-xl bg-blue-50/50 border border-blue-100 focus:border-blue-500 outline-none transition-all text-blue-900 font-medium text-sm"
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="text-xs font-bold text-blue-400 uppercase tracking-widest flex items-center gap-2">
                          <Clock className="w-3 h-3" /> Session
                        </label>
                        <select
                          value={slot}
                          onChange={(e) => setSlot(e.target.value)}
                          className="w-full px-4 py-3 rounded-xl bg-blue-50/50 border border-blue-100 focus:border-blue-500 outline-none transition-all text-blue-900 font-medium text-sm appearance-none"
                        >
                          <option value="Morning Prayer">Morning Prayer</option>
                        </select>
                      </div>

                      <button
                        onClick={handleSubmit}
                        disabled={loading || !date || !name || !phone}
                        className="w-full py-4 bg-blue-600 text-white rounded-xl font-bold shadow-lg shadow-blue-100 hover:bg-blue-700 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                      >
                        {loading ? 'Processing...' : (editingId ? 'Update Booking' : 'Confirm Booking')}
                        {!loading && <ChevronRight className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {message && (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className={`p-4 rounded-2xl flex items-center gap-3 ${message.type === 'success' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 'bg-rose-50 text-rose-700 border border-rose-100'}`}
                    >
                      {message.type === 'success' ? <CheckCircle className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
                      <span className="text-sm font-semibold">{message.text}</span>
                    </motion.div>
                  )}
                </motion.div>
              ) : activeTab === 'manage' ? (
                <motion.div
                  key="manage-tab"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="space-y-6"
                >
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                    {/* Left: Calendar (Reuse the same calendar logic) */}
                    <div className="lg:col-span-5">
                      <div className="bg-white rounded-3xl p-6 shadow-xl border border-blue-50">
                        <div className="flex items-center justify-between mb-6 px-2">
                          <h3 className="text-xl font-bold text-blue-900">
                            {currentCalendarDate.toLocaleString('default', { month: 'long', year: 'numeric' })}
                          </h3>
                          <div className="flex gap-2">
                            <button onClick={() => changeMonth(-1)} className="p-2 hover:bg-blue-50 rounded-full text-blue-600 transition-colors">
                              <ChevronLeft className="w-5 h-5" />
                            </button>
                            <button onClick={() => changeMonth(1)} className="p-2 hover:bg-blue-50 rounded-full text-blue-600 transition-colors">
                              <ChevronRight className="w-5 h-5" />
                            </button>
                          </div>
                        </div>

                        <div className="grid grid-cols-7 gap-1 mb-2">
                          {['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'].map(day => (
                            <div key={day} className="text-center text-[10px] font-black text-blue-400 py-2">
                              {day}
                            </div>
                          ))}
                        </div>

                        <div className="grid grid-cols-7 gap-1">
                          {renderCalendar()}
                        </div>

                        <div className="mt-8 flex items-center justify-between px-2">
                          <div className="flex items-center gap-2">
                            <div className="w-3 h-3 bg-blue-600 rounded-full" />
                            <span className="text-[10px] font-bold text-blue-600 uppercase">Selected</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="w-3 h-3 bg-rose-100 rounded-full" />
                            <span className="text-[10px] font-bold text-blue-600 uppercase">Booked</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="w-3 h-3 border border-blue-200 rounded-full" />
                            <span className="text-[10px] font-bold text-blue-600 uppercase">Available</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Right: Recent Bookings */}
                    <div className="lg:col-span-7 space-y-6">
                      <div className="flex items-center justify-between">
                        <h2 className="text-2xl font-black text-blue-900 tracking-tight">Recent Bookings</h2>
                        <div className="bg-white px-4 py-1.5 rounded-full border border-blue-100 shadow-sm">
                          <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest">{totalBookings} TOTAL</span>
                        </div>
                      </div>

                      <div className="space-y-4">
                        {bookings.length === 0 ? (
                          <div className="text-center py-20 bg-white/50 rounded-3xl border border-dashed border-blue-200">
                            <Calendar className="w-12 h-12 mx-auto mb-3 text-blue-200" />
                            <p className="text-blue-400 font-bold">No bookings found yet.</p>
                          </div>
                        ) : (
                          bookings.map((booking) => (
                            <motion.div
                              layout
                              key={booking.id}
                              className="bg-white rounded-3xl p-6 border border-blue-50 shadow-xl hover:shadow-2xl transition-all relative group"
                            >
                              <div className="flex items-start justify-between mb-4">
                                <div className="flex items-center gap-4">
                                  <div className="w-12 h-12 rounded-full bg-blue-50 flex items-center justify-center text-blue-600 font-black text-lg border-2 border-white shadow-sm">
                                    {booking.name.charAt(0).toUpperCase()}
                                  </div>
                                  <div>
                                    <h4 className="text-lg font-black text-blue-900 leading-tight">{booking.name}</h4>
                                    <div className="flex items-center gap-1.5 text-blue-400 font-bold text-[10px] uppercase tracking-wider mt-1">
                                      <Clock className="w-3 h-3" />
                                      {formatDateDisplay(booking.date)}
                                    </div>
                                  </div>
                                </div>
                                <div className="flex gap-1">
                                  <button
                                    onClick={() => handleEdit(booking)}
                                    className="p-2.5 bg-blue-50 text-blue-600 rounded-xl hover:bg-blue-100 transition-colors"
                                  >
                                    <Edit2 className="w-4 h-4" />
                                  </button>
                                  <button
                                    onClick={() => handleDelete(booking.id)}
                                    className="p-2.5 bg-rose-50 text-rose-500 rounded-xl hover:bg-rose-100 transition-colors"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </div>
                              </div>
                              
                              <div className="flex items-center gap-2 text-blue-500 font-bold text-sm">
                                <Phone className="w-4 h-4" />
                                <span>{booking.phone}</span>
                              </div>
                            </motion.div>
                          ))
                        )}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ) : (
                <motion.div
                  key="admin-tab"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="bg-white rounded-3xl p-8 shadow-2xl border border-blue-50"
                >
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-blue-900 font-bold flex items-center gap-2">
                      <Settings className="w-5 h-5" /> Prayer Times Admin
                    </h3>
                    <div className="flex gap-2">
                      <input
                        type="file"
                        accept=".csv"
                        className="hidden"
                        ref={fileInputRef}
                        onChange={handleCsvUpload}
                      />
                      <button
                        onClick={() => fileInputRef.current?.click()}
                        className="px-4 py-2 bg-blue-50 text-blue-600 rounded-xl text-xs font-bold uppercase tracking-widest flex items-center gap-2 hover:bg-blue-100 transition-all"
                      >
                        <Upload className="w-4 h-4" /> Upload CSV
                      </button>
                      <button
                        onClick={saveAdminTimes}
                        disabled={loading}
                        className="px-4 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold uppercase tracking-widest flex items-center gap-2 hover:bg-blue-700 transition-all shadow-lg shadow-blue-100"
                      >
                        <Save className="w-4 h-4" /> {loading ? 'Saving...' : 'Save Changes'}
                      </button>
                    </div>
                  </div>

                  {message && (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className={`p-4 mb-6 rounded-2xl flex items-center gap-3 ${message.type === 'success' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 'bg-rose-50 text-rose-700 border border-rose-100'}`}
                    >
                      {message.type === 'success' ? <CheckCircle className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
                      <span className="text-sm font-semibold">{message.text}</span>
                    </motion.div>
                  )}

                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="border-b border-blue-50">
                          <th className="py-3 px-4 text-xs font-bold text-blue-400 uppercase">Month</th>
                          <th className="py-3 px-4 text-xs font-bold text-blue-400 uppercase">Morning Time</th>
                          <th className="py-3 px-4 text-xs font-bold text-blue-400 uppercase">Evening Time</th>
                        </tr>
                      </thead>
                      <tbody>
                        {adminTimes.map((time, idx) => (
                          <tr key={time.month} className="border-b border-blue-50/50 hover:bg-blue-50/30 transition-colors">
                            <td className="py-3 px-4 font-bold text-blue-900">{time.month}</td>
                            <td className="py-2 px-4">
                              <input
                                type="text"
                                value={time.morning}
                                onChange={(e) => handleAdminTimeChange(idx, 'morning', e.target.value)}
                                className="w-full px-3 py-2 rounded-lg bg-blue-50/50 border border-blue-100 focus:border-blue-500 outline-none text-sm"
                              />
                            </td>
                            <td className="py-2 px-4">
                              <input
                                type="text"
                                value={time.evening}
                                onChange={(e) => handleAdminTimeChange(idx, 'evening', e.target.value)}
                                className="w-full px-3 py-2 rounded-lg bg-blue-50/50 border border-blue-100 focus:border-blue-500 outline-none text-sm"
                              />
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Footer */}
        <footer className="mt-20 text-center text-blue-400 text-sm font-medium">
          <p>© {new Date().getFullYear()} Budigere Cross — Divine Prayer Booking</p>
          <div className="flex items-center justify-center gap-4 mt-4">
            <a href="#" className="hover:text-blue-600 transition-colors">Privacy Policy</a>
            <span className="w-1 h-1 bg-blue-200 rounded-full" />
            <a href="#" className="hover:text-blue-600 transition-colors">Terms of Service</a>
            <span className="w-1 h-1 bg-blue-200 rounded-full" />
            <a href="#" className="hover:text-blue-600 transition-colors">Contact Us</a>
          </div>
        </footer>
      </div>
    </div>
  );
}
